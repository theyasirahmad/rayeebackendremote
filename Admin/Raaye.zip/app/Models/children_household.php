<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class children_household extends Model
{
    protected $table = 'children_household';
    protected $fillable = ['title'];
}
