<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class children_group extends Model
{
    protected $table = 'children_group';
    protected $fillable = ['title'];
}
