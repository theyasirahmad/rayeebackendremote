<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveyGridQuestion extends Model
{
    protected $fillable = ['question','question_id'];
}
