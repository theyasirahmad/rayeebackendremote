<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class occupation extends Model
{
    protected $table = 'occupation';
    protected $fillable = ['title'];
}
