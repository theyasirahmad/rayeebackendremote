

<?php $__env->startSection('header'); ?>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
<!-- Page header -->
			<div class="page-header page-header-light">
				<div class="page-header-content header-elements-md-inline">
					<div class="page-title d-flex">
						<h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Dashboard</span> - Survey Details</h4>
						<a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
					</div>

					<div class="header-elements d-none">
						<div class="d-flex justify-content-center">
							
						</div>
					</div>
				</div>

				<div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
					<div class="d-flex">
						<div class="breadcrumb">
							<a href="javascript:void(0)" class="breadcrumb-item"><i class="icon-home mr-2"></i> Dashboard</a>
							<span class="breadcrumb-item active">Survey Details</span>
						</div>

						<a href="<?php echo e(url('/admin/dashboard')); ?>" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
					</div>

					<div class="header-elements d-none">
						<div class="breadcrumb justify-content-center">

							
						</div>
					</div>
				</div>
			</div>
            <!-- /page header -->
            
            <div class="content">

            <div class="card" id="form" style="display:none">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title">Create Survey</h5>
                <div class="header-elements">
                    <div class="list-icons">
                    <Button type="button" id="btnClose" class="btn icon-close2 btn-danger"></Button>
                </div>
                    </div>
            </div>
            <form id="surveyForm">
            <div class="card-body">

                <div class="row">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Survey Title</label>
                            <input type="text" class="form-control" placeholder="Survey Title" name="title" required>
                            <small><span class="error_msg" id="title_msg"></span></small>
                        </div>
                    </div>

                        <div class="col-md-6">
                        <div class="form-group">
                            <label>Category</label>
                            <select class="form-control" name="category" required id="category">
                            <option disabled hidden Selected>Select Category</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <small><span class="error_msg" id="category_msg"></span></small>
                        </div>
                        </div>

                        <div class="col-md-6">
                        <div class="form-group">
                            <label>Sub Category</label>
                            <select class="form-control" name="subCategory" required id="subCategory">
                            <option disabled hidden Selected>Select Sub Category</option>
                            </select>
                            <small><span class="error_msg" id="subCategory_msg"></span></small>
                        </div>
                        </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Survey Cost</label>
                            <select class="form-control" name="cost" required>
                                <option disabled hidden Selected>Select Cost</option>
                                <?php $__currentLoopData = $costing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?> - <?php echo e($item->type); ?> - Rs<?php echo e($item->price); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <small><span class="error_msg" id="cost_msg"></span></small>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Select Image</label>
                            <input type="file" name="file" class="form-control" />
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Survey Total Time</label>
                            <input type="number" class="form-control" placeholder="Total Time" name="totalTime" required>
                            <small><span class="error_msg" id="totalTime_msg"></span></small>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Survey Avg Time</label>
                            <input type="number" class="form-control" placeholder="Survey Avg Time" name="avgTime" required>
                            <small><span class="error_msg" id="avgTime_msg"></span></small>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Discription</label>
                            <textarea rows="3" cols="3" class="form-control" placeholder="Discription" required name="discription"></textarea>
                            <small><span class="error_msg" id="discription_msg"></span></small>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <input type="submit" class="btn btn-sm btn-primary" style="float: right" value="Create"/>
                        </div>
                    </div>

                </div>

            </div>
            </form>
            </div>

            <div class="card" id="table">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title">Survey Details</h5>
                    <div class="header-elements">
                        <div class="list-icons">
                        <Button type="button" id="btnOpen" class="btn btn-primary icon-add"> Survey</Button>
                        <a href="<?php echo e(url('/admin/survey-category')); ?>" class="btn btn-primary icon-add"> Category</a>
                        <a href="<?php echo e(url('/admin/survey-sub-category')); ?>" class="btn btn-primary icon-add"> Sub Category</a>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
					<table class="table" id="surveyTable" style="width: 100%">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Sub Category</th>
                                <th>Cost</th>
                                <th>Status</th>
                                <th>Discription</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                    </table>
                
                </div>

            </div>


            </div>




			
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Publish Survey</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form id="publishForm">
            <div class="modal-body">
              <div class="row">
                  <?php echo csrf_field(); ?>
                <input type="hidden" id="survey" name="survey"/>
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Gender</label>
                        <select class="form-control" name="publish" required>
                        <option disabled hidden Selected>Select Publish</option>
                        <option value="all">All</option>
                        <option value="1">Male</option>
                        <option value="2">Female</option>
                        </select>
                        <small><span class="error_msg" id="publish_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Education</label>
                        <select class="form-control" name="education" required>
                        <option disabled hidden Selected>Select Education</option>
                        <option value="all">All</option>
                        <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><span class="error_msg" id="education_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Occupation</label>
                        <select class="form-control" name="occupation" required>
                        <option disabled hidden Selected>Select Occupation</option>
                        <option value="all">All</option>
                        <?php $__currentLoopData = $occupation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><span class="error_msg" id="occupation_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Children Group</label>
                        <select class="form-control" name="childrenGroup" required>
                        <option disabled hidden Selected>Select Children Group</option>
                        <option value="all">All</option>
                        <?php $__currentLoopData = $childrenGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><span class="error_msg" id="childrenGroup_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Children Household</label>
                        <select class="form-control" name="childrenHousehold" required>
                        <option disabled hidden Selected>Select Children Household</option>
                        <option value="all">All</option>
                        <?php $__currentLoopData = $childrenHousehold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><span class="error_msg" id="childrenHousehold_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Household Category</label>
                        <select class="form-control" name="householdCategory" required>
                        <option disabled hidden Selected>Select Household Category</option>
                        <option value="all">All</option>
                        <?php $__currentLoopData = $childrenHouseholdCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><span class="error_msg" id="householdCategory_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Purchasing Role</label>
                        <select class="form-control" name="purchasingRole" required>
                        <option disabled hidden Selected>Select Purchasing Role</option>
                        <option value="all">All</option>
                        <?php $__currentLoopData = $purchasingRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><span class="error_msg" id="purchasingRole_msg"></span></small>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Survey Expiry Date</label>
                        <input type="date" class="form-control" placeholder="Expiry Date" required name="expiry"/>
                        <small><span class="error_msg" id="expiry_msg"></span></small>
                    </div>
                </div>

              </div>
            </div>
            <div class="modal-footer">
              <input type="submit" class="btn btn-primary" value="Publish" />
            </div>
        </form>
          </div>
        </div>
      </div>

<script src="<?php echo e(url('/public/assets/global_assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('/public/assets/global_assets/js/demo_pages/datatables_basic.js')); ?>"></script>
<script src="<?php echo e(url('/public/assets/ajax/survey-category.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.adminMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/raaye/public_html/resources/views/Admin/survey.blade.php ENDPATH**/ ?>