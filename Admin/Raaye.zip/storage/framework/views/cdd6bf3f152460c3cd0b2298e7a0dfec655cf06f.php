<?php $__env->startSection('header'); ?>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
<!-- Page header -->
			<div class="page-header page-header-light">
				<div class="page-header-content header-elements-md-inline">
					<div class="page-title d-flex">
						<h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">User</span> - User Details</h4>
						<a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
					</div>

					<div class="header-elements d-none">
						<div class="d-flex justify-content-center">
							
						</div>
					</div>
				</div>

				<div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
					<div class="d-flex">
						<div class="breadcrumb">
							<a href="index.html" class="breadcrumb-item"><i class="icon-user mr-2"></i> User</a>
							<span class="breadcrumb-item active">User Details</span>
						</div>

						<a href="<?php echo e(url('/admin/user')); ?>" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
					</div>

					<div class="header-elements d-none">
						<div class="breadcrumb justify-content-center">

							
						</div>
					</div>
				</div>
			</div>
            <!-- /page header -->
            
            <div class="content">

            <div class="card">
                <div class="card-header header-elements-inline">
                    <h5 class="card-title">User Details</h5>
                    <div class="header-elements">
                        <div class="list-icons">
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
					<table class="table text-center">
                    <?php if($user->image != ''){ ?>
                    <tr>
                        <img src="<?php echo e(url('public/storage/userImage/').'/'.$user->image); ?>" style="width:300px; max-height:300px"/>
                    </tr>
                    <?php } ?>

                    <tr>
                        <td>First name</td>
                        <td><?php echo e($user->first_name); ?></td>
                    </tr>

                    <tr>
                        <td>First name</td>
                        <td><?php echo e($user->last_name); ?></td>
                    </tr>

                    <tr>
                        <td>Gender</td>
                        <td><?php echo e($user->gender == '1' ? 'Male' : 'Female'); ?></td>
                    </tr>
                        
                    <tr>
                        <td>Email</td>
                        <td><?php echo e($user->email); ?></td>
                    </tr>

                    <tr>
                        <td>Phone</td>
                        <td><?php echo e($user->phone); ?></td>
                    </tr>

                    <tr>
                        <td>Mobile Network</td>
                        <td><?php echo e($user->mobile_network); ?></td>
                    </tr>

                    <tr>
                        <td>Date Of Birth</td>
                        <td><?php echo e($user->dob); ?></td>
                    </tr>

                    <tr>
                        <td>Education</td>
                        <td><?php echo e(@$user->education_det->title); ?></td>
                    </tr>

                    <tr>
                        <td>Occupation</td>
                        <td><?php echo e(@$user->occupation_det->title); ?></td>
                    </tr>
    
                    <tr>
                        <td>Marital Status</td>
                        <td><?php echo e($user->marital_status); ?></td>
                    </tr>
    
                    <tr>
                        <td>Children</td>
                        <td><?php echo e($user->children); ?></td>
                    </tr>
    
                    <tr>
                        <td>Children Group</td>
                        <td><?php echo e(@$user->children_group_det->title); ?></td>
                    </tr>
    
                    <tr>
                        <td>Children Household</td>
                        <td><?php echo e(@$user->children_household_det->title); ?></td>
                    </tr>
    
                    <tr>
                        <td>Household</td>
                        <td><?php echo e(@$user->house_hold_det->title); ?></td>
                    </tr>
    
                    <tr>
                        <td>Role Purchasing</td>
                        <td><?php echo e(@$user->role_purchasing_det->title); ?></td>
                    </tr>

                    </table>
                
                </div>

            </div>


            </div>




			
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.adminMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey\resources\views/admin/user-details.blade.php ENDPATH**/ ?>